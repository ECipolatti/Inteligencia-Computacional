function [ Particiones ,g] = leave_k_out(Data, k)
    Data = mezclar(Data);
    [N M] = size(Data);
    % Cantidad de Grupos neesarios, hay que corroborar que N y K 
    if floor(N/k) == N/k
        g = N/k;
    else
        g = floor(N/k) + 1;
    end
    
    for i = 1 : g
       Particiones{i}.E = zeros(N-k, M);
       Particiones{i}.P = zeros(k, M);        
    end

    for i = 1 : k : N-k
       Particiones{(i-1)/k+1}.P = Data(i : i+k-1 ,:);
       Particiones{(i-1)/k+1}.E = [Data(1:i-1,:);Data(i+k:N,:)];
    end
    
    Particiones{g}.P = Data(N :-1: N-k+1, :);
    Particiones{g}.E = Data(1:N-k, :);
end

