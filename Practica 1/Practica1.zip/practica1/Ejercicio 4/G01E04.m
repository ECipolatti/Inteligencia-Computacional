% PERCEPTRON MULTICAPA con Salidas Multiples
addpath('../archdatos');
% Variables:
clear all; close all;

MaxEp = 10;        % Maximo Epocas
TolEr = 1;          % Tolerancia Error
MomRt = 0.2;        % Taza momento
LearnRt = 0.05;     % Taza aprendizaje
num_salidas = 3;     % Numero Salidas
num_entradas = 4;    % Numero Entradas

vec_num_neu = [3 3];                  % Vector Num de neuronas por capa
num_capas = length(vec_num_neu);        % Num de capas

Data = csvread('irisbin.csv');      % Datos de entrada
[n m] = size(Data);

vec_error = zeros(MaxEp, 1);
X = [-ones(n,1) Data(:, 1:num_entradas)];           % Matriz X extendida
Yd = Data(:, num_entradas+1:end);                   % MAtriz Yd, salidas deseadas
Y = zeros(n,num_salidas);                           % Salida


capa{1}.W = rand(vec_num_neu(1), length(X(1,:)))-0.5;
capa{1}.DW = zeros(vec_num_neu(1), length(X(1,:)));
capa{1}.Y = zeros(vec_num_neu(1), 1);
capa{1}.D = zeros(vec_num_neu(1), 1);
for i=2 : num_capas
    capa{i}.W = rand(vec_num_neu(i), vec_num_neu(i-1)+1) - 0.5;
    capa{i}.DW = zeros(vec_num_neu(i), vec_num_neu(i-1)+1);
    capa{i}.Y = zeros(vec_num_neu(i), 1);
    capa{i}.D = zeros(vec_num_neu(i), 1);
end

Ep = 1;
Er = 100;
while Ep < MaxEp %&& TolEr < Er
    % Calculando los mejores W
    for p=1 : n % p recorre por patron
        
        % Propagacion hacia Adelante
        capa{1}.Y = capa{1}.W * X(p, :)';
        capa{1}.Y = (sigmf(capa{1}.Y,[10 0]) - 0.5) * 2;
        Y(1,:) = capa{1}.Y;
        for c=2 : num_capas     % c es indices de capas 
            capa{c}.Y = capa{c}.W * [-1; capa{c-1}.Y];
            capa{c}.Y = (sigmf(capa{c}.Y, [10 0]) - 0.5) * 2;
            Y(c,:) = capa{c}.Y;
        end
        
        capa{num_capas}.Y=descodificar(capa{num_capas}.Y);
        % Propagacion - deltas
        error = Yd(p,:)' - capa{num_capas}.Y;
        %Calculo los Deltas
        capa{num_capas}.D = 0.5 .* error .* (1+capa{num_capas}.Y) .* (1-capa{num_capas}.Y);  % delta en la ultima capa
        for k=(num_capas-1): -1 : 1
             capa{k}.D = (capa{k+1}.W(:,2:end)' * capa{k+1}.D) .* 0.5 .* (1+capa{k}.Y) .* (1-capa{k}.Y);
        end
        
        % Actualizo los pesos
        %capa{1}.W = capa{1}.W + LearnRt * capa{1}.D * X(p,:); 
        capa{1}.W = capa{1}.W + LearnRt * capa{1}.D * X(p,:) + MomRt * capa{1}.DW; % actualizo con momento
        capa{1}.DW = LearnRt * capa{1}.D * X(p,:) + MomRt * capa{1}.DW; % guardo DW 
        for c=2 : num_capas
           %capa{c}.W = capa{c}.W + (LearnRt * capa{c}.D * [-1; capa{c-1}.Y]');
           capa{c}.W = capa{c}.W + (LearnRt * capa{c}.D * [-1; capa{c-1}.Y]') + MomRt * capa{c}.DW; % actualizo con momento
           capa{c}.DW = (LearnRt * capa{c}.D * [-1; capa{c-1}.Y]') + MomRt * capa{c}.DW; % guardo DW
        end
    end  % end for - ACA TERMINA LA EPOCA DEJANDO EL MEJOR W PARA CADA CAPA 
    
%     % Calculo porcentaje error
%     Er = 0;
%     for p=1 : n % p recorre por patron
%         
%         % Propagacion hacia Adelante
%         capa{1}.Y = capa{1}.W * X(p,:)';
%         capa{1}.Y = (sigmf(capa{1}.Y,[10 0]) - 0.5) * 2;
%         for c=2 : num_capas % c es indices de capas 
%             capa{c}.Y = capa{c}.W * [-1; capa{c-1}.Y];
%             capa{c}.Y = (sigmf(capa{c}.Y, [10 0]) - 0.5) * 2;
%         end
%        
%         Y(p) = sign(capa{num_capas}.Y);
%         if Y(p) ~= Yd(p)
%            Er = Er + 1;
%         end
%     end
%     Er = (Er*100)/n;
%     vec_error(Ep) = Er;
    
    % Incremento las Epocas
    Ep=Ep+1; 
end


% figure(1)
% grafica(X,Yd,Y);
% subplot(2,1,1)
% scatter(X(:,2),X(:,3),15,Yd);
% subplot(2,1,2)
% scatter(X(:,2),X(:,3),30,Y,'x');
%  plot(linspace(0,10,length(vec_error)),vec_error)


