function [y]=descodificar(Y)
    [n m]=size(Y);
    y=-ones(n,m);
    for i=1:n
        for j=1:m
            if Y(i,j)==max(Y(i,:));
                y(i,j)=1;
            end
        end
    end
end