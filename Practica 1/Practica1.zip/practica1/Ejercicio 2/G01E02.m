%% Guia 1 - Ejercicio 2
clc;
clear;
addpath('../archdatos');

%% Entrenamiento

% Leo los datos a utilizar y realizo las particiones
DataLrn = csvread('spheres1d10.csv');
nro_part=5;
por_trn=80;
[DTrn , DTst]= particion(nro_part, por_trn, DataLrn);

% Llamo a la funcion de aprendizaje con cada particion 
 LrnRt = 0.1;
 MaxEp = 40;
 TolEr = 10;
 m = size(DTrn,2); %Columnas de DataLrn
 vec_Er = zeros(1,nro_part);
 vec_W = zeros(m,1,1,nro_part);
 figure(1);
for i=1:nro_part
    fprintf('particion: %d\n',i);
    
    W0 = rand(1,m)-0.5;
    X = DTrn(:,1:3,1,i);
    Yd = DTrn(:,4,1,i);
    
    [W,SC,Ep,Er] = Learn2(X,Yd,W0,LrnRt,MaxEp,TolEr,i);
    vec_Er(i)=Er;
    vec_W(:,:,1,i) = W; 
    fprintf('Porcentaje de aciertos en el aprendizaje: %d\nCantidad de Epocas utilizadas: %d\n',SC,Ep);
    
end


%% Test
fprintf('\n \n---- TEST ------\n');
vec_Sc = zeros(1,nro_part);
figure(2);
for i=1:nro_part
    X = DTst(:,1:3,1,i);
    Yd = DTst(:,4,1,i);
    % Llamo a la funcion
    [Sc] = Test(X,Yd,W,i);
    fprintf('Porcentaje de aciertos en la prueba num %d: %d\n',i,Sc);
    vec_Sc(i) = Sc; 
end

fprintf('\n---- RESULTADOS ------ \n');
prom = mean(vec_Sc);
var = var(vec_Sc);
fprintf('Promedio Acierto: %d   Varianza: %d\n',prom,var);
